with base_player_information as 
(
   select
      ply.player_id,
      brn.brand_name,
      mkt.market_name,
      acquisition_channel 
   from
      players_table ply 
      left join
         dim_brand brn 
         on ply.brand_id = brn.brand_id 
      left join
         dim_market mkt 
         on ply.market_id = mkt.market_id 
   where
      is_test_account = 'FALSE'
)
,
--- firt time table 
first_time_table as 
(
   SELECT
      player_id,
      MIN(time)AS first_deposi_date,
      --- to tranform to date later
      transanction_type,
      description,
      amount as first_deposit_amount 
   FROM
      Transactions 
      LEFT JOIN
         dim_transaction_type 
         ON Transactions.transanction_type = dim_transaction_type.id 
   WHERE
      UPPER(dim_transaction_type.description) = 'DEPOSIT' 
   GROUP BY
      player_id,
      transanction_type,
      description 
   HAVING
      time = first_deposi_date
)
,
last_time_table as 
(
   SELECT
      player_id,
      MAX(time)AS last_deposit_date,
      --- to tranform to date later
      transanction_type,
      description,
      amount as last_deposit_amount 
   FROM
      Transactions 
      LEFT JOIN
         dim_transaction_type 
         ON Transactions.transanction_type = dim_transaction_type.id 
   WHERE
      UPPER(dim_transaction_type.description) = 'DEPOSIT' 
   GROUP BY
      player_id,
      transanction_type,
      description 
   HAVING
      time = last_deposit_date
)
,
deposit_table as 
(
   SELECT
      player_id,
      transanction_type,
      description,
      sum(amount) as total_deposit 
   FROM
      Transactions 
      LEFT JOIN
         dim_transaction_type 
         ON Transactions.transanction_type = dim_transaction_type.id 
   WHERE
      UPPER(dim_transaction_type.description) like '%DEPOSIT%' 
   GROUP BY
      player_id 
)
,
bet_table as 
(
   SELECT
      player_id,
      transanction_type,
      description,
      sum(amount) as total_bet 
   FROM
      Transactions 
      LEFT JOIN
         dim_transaction_type 
         ON Transactions.transanction_type = dim_transaction_type.id 
   WHERE
      UPPER(dim_transaction_type.description) like '%BET%' 
   GROUP BY
      player_id 
)
,
win_table as 
(
   SELECT
      player_id,
      transanction_type,
      description,
      sum(amount) as total_win 
   FROM
      Transactions 
      LEFT JOIN
         dim_transaction_type 
         ON Transactions.transanction_type = dim_transaction_type.id 
   WHERE
      UPPER(dim_transaction_type.description) like '%WIN%' 
   GROUP BY
      player_id 
)
,
active_day as 
(
   select
      count(DISTINCT date(time)) as active_days,
      player_id 
   from
      Transactions 
   group by
      player_id
)
,
daily_win as
(
   SELECT
      player_id,
      transanction_type,
      description,
      sum(amount) as daily_win,
      date(time) as date 
   FROM
      Transactions 
      LEFT JOIN
         dim_transaction_type 
         ON Transactions.transanction_type = dim_transaction_type.id 
   WHERE
      UPPER(dim_transaction_type.description) like '%WIN%' 
   GROUP BY
      player_id,
      date(time),
      Transactions.transanction_type
)
,
daily_wadge as
(
   SELECT
      player_id,
      transanction_type,
      sum(amount) as daily_wadge,
      date(time) as date 
   FROM
      Transactions 
      LEFT JOIN
         dim_transaction_type 
         ON Transactions.transanction_type = dim_transaction_type.id 
   WHERE
      UPPER(dim_transaction_type.description) like '%BET%' 
   GROUP BY
      player_id,
      date(time),
      Transactions.transanction_type 
)
,
daily_ggw as 
(
   select
      coalesce(daily_win.player_id, daily_wadge.player_id ) as player_id,
      --coalesce( date(daily_win.time), date(daily_wadge.time) ) as date,
      ifnull(daily_wadge, 0) as daily_wadge,
      ifnull(daily_win, 0) as daily_win,
      coalesce(daily_win.date , daily_wadge.date) as date,
      daily_win - daily_wadge as daily_ggw 
   from
      daily_win 
      FULL OUTER JOIN
         daily_wadge 
         on daily_win.player_id = daily_wadge.player_id 
         and daily_win.date = daily_wadge.date 
)
,
daily_ggw_repo as 
(
   select
      max(daily_ggw) as max_daily_ggw,
      min(daily_ggw) as min_daily_ggw,
      player_id 
   from
      daily_ggw 
   group by
      player_id
)
select
   base.*,
   date(ft.first_deposi_date) as first_deposit_date,
   round(ifnull(ft.first_deposit_amount, 0), 2) as first_deposit_amount,
   date(lt.last_deposit_date) as last_deposit_date,
   round(ifnull(lt.last_deposit_amount, 0), 2) as last_deposit_amount,
   round(ifnull(total_deposit, 0), 2) as total_deposits,
   round(ifnull(total_bet, 0), 2) as total_bets,
   round(ifnull(total_win, 0), 2) as total_win,
   ac_d.active_days,
   max_daily_ggw,
   min_daily_ggw 
from
   base_player_information base 
   left join
      first_time_table ft 
      on base.player_id = ft.player_id 
   left join
      last_time_table lt 
      on base.player_id = lt.player_id 
   left join
      deposit_table dp 
      on base.player_id = dp.player_id 
   left join
      bet_table bet 
      on base.player_id = bet.player_id 
   left join
      win_table win 
      on base.player_id = win.player_id 
   left join
      active_day ac_d 
      on base.player_id = ac_d.player_id 
   left join
      daily_ggw_repo 
      on base.player_id = daily_ggw_repo.player_id ;