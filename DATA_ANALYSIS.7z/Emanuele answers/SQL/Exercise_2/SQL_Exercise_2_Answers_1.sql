with transaction_info as 
(
   select distinct
      date(time) as date,
      time,
      amount,
      description,
      brand_name,
      market_name,
      acquisition_channel,
      fact.player_id,
      fact.status 
   from
      Transactions fact 
      left join
         dim_transaction_type dim_tra 
         on fact.transanction_type = dim_tra.id 
      LEFT join
         players_table ply_dim 
         on ply_dim.player_id = fact.player_id 
      left join
         dim_market mkt_dim 
         on ply_dim.market_id = mkt_dim.market_id 
      left join
         dim_brand 
         on ply_dim.brand_id = dim_brand.brand_id 
   group by
      date,
      brand_name,
      market_name,
      acquisition_channel,
      description 
)
,
win_information as 
(
   select
      sum(round(amount, 2)) as total_win,
      date,
      brand_name,
      market_name,
      acquisition_channel 
   from
      transaction_info 
   where
      description LIKE '%_win%' 
   group by
      date,
      brand_name,
      market_name,
      acquisition_channel,
      description 
)
,
bet_information as 
(
   select
      count(player_id) as active_player,
      sum(round(amount, 2)) as total_bet,
      date,
      brand_name,
      market_name,
      acquisition_channel 
   from
      transaction_info 
   where
      description LIKE '%bet%' 
   group by
      date,
      brand_name,
      market_name,
      acquisition_channel,
      description
)
,
-- casino bet and  win part 
bet_casino as 
(
   select
      count(player_id) as active_player,
      sum(round(amount, 2)) as casino_bet,
      date,
      brand_name,
      market_name,
      acquisition_channel 
   from
      transaction_info 
   where
      description LIKE '%casino_bet%' 
   group by
      date,
      brand_name,
      market_name,
      acquisition_channel,
      description
)
,
win_casino as 
(
   select
      count(player_id) as active_player,
      sum(round(amount, 2)) as casino_win,
      date,
      brand_name,
      market_name,
      acquisition_channel 
   from
      transaction_info 
   where
      description LIKE '%casino_win%' 
   group by
      date,
      brand_name,
      market_name,
      acquisition_channel,
      description
)
,
--  end of casino bet and win part 
-- sport bet win part 
bet_sport as 
(
   select
      count(player_id) as active_player,
      sum(round(amount, 2)) as sport_bet,
      date,
      brand_name,
      market_name,
      acquisition_channel 
   from
      transaction_info 
   where
      description LIKE 'sports_bet%' 
   group by
      date,
      brand_name,
      market_name,
      acquisition_channel,
      description
)
,
win_sport as 
(
   select
      count(player_id) as active_player,
      sum(round(amount, 2)) as sport_win,
      date,
      brand_name,
      market_name,
      acquisition_channel 
   from
      transaction_info 
   where
      description LIKE '%sports_win%' 
   group by
      date,
      brand_name,
      market_name,
      acquisition_channel,
      description
)
,
-- end of sport bet and win part 
completed_deposit as 
(
   select
      sum( depo_with.amount) as completed_deposit,
      date,
      brand_name,
      market_name,
      acquisition_channel,
      description 
   from
      transaction_info depo_with 
   where
      upper(depo_with.description) in 
      (
         'DEPOSIT'
      )
      and upper(depo_with.status) = 'CONFIRMED' 
   group by
      date,
      brand_name,
      market_name,
      acquisition_channel,
      description
)
,
completed_withrawal as 
(
   select
      sum( depo_with.amount) as completed_withrawal,
      date,
      brand_name,
      market_name,
      acquisition_channel,
      description 
   from
      transaction_info depo_with 
   where
      upper(depo_with.description) in 
      (
         'WITHRAWAL'
      )
      and upper(depo_with.status) = 'CONFIRMED' 
   group by
      date,
      brand_name,
      market_name,
      acquisition_channel,
      description
)
select DISTINCT
   transaction_info.date,
   transaction_info.brand_name,
   transaction_info.market_name,
   transaction_info.acquisition_channel,
   ifnull(bet.active_player,0) as active_player,
   ifnull(bet.total_bet,0) as total_bet, 
   ifnull( win.total_win,0) as total_win,
   ifnull(casino_bet, 0) as casino_bet,
   ifnull(casino_win,0) as casino_win,
   ifnull(sport_bet ,0) as sport_bet,
   ifnull(sport_win, 0) as  sport_win,
   ifnull(total_bet, 0) - ifnull(total_win, 0) as ggw,
   ifnull(completed_deposit, 0) as completed_deposit,
   ifnull(completed_withrawal, 0) as completed_withrawal 
from
   transaction_info 
   left join
      bet_information bet 
      on transaction_info.date = bet.date 
      and transaction_info.brand_name = bet.brand_name 
      and transaction_info.market_name = bet.market_name 
      and transaction_info.acquisition_channel = bet.acquisition_channel 
   left join
      win_information win 
      on transaction_info.date = win.date 
      and transaction_info.brand_name = win.brand_name 
      and transaction_info.market_name = win.market_name 
      and transaction_info.acquisition_channel = win.acquisition_channel 
   left join
      bet_casino b_cas 
      on transaction_info.date = b_cas.date 
      and transaction_info.brand_name = b_cas.brand_name 
      and transaction_info.market_name = b_cas.market_name 
      and transaction_info.acquisition_channel = b_cas.acquisition_channel 
   left join
      win_casino w_cas 
      on transaction_info.date = w_cas.date 
      and transaction_info.brand_name = w_cas.brand_name 
      and transaction_info.market_name = w_cas.market_name 
      and transaction_info.acquisition_channel = w_cas.acquisition_channel 
   left join
      bet_sport b_spo 
      on transaction_info.date = b_spo.date 
      and transaction_info.brand_name = b_spo.brand_name 
      and transaction_info.market_name = b_spo.market_name 
      and transaction_info.acquisition_channel = b_spo.acquisition_channel 
   left join
      win_sport w_spo 
      on transaction_info.date = w_spo.date 
      and transaction_info.brand_name = w_spo.brand_name 
      and transaction_info.market_name = w_spo.market_name 
      and transaction_info.acquisition_channel = w_spo.acquisition_channel 
   left join
      completed_deposit c_depo 
      on transaction_info.date = c_depo.date 
      and transaction_info.brand_name = c_depo.brand_name 
      and transaction_info.market_name = c_depo.market_name 
      and transaction_info.acquisition_channel = c_depo.acquisition_channel 
   left join
      completed_withrawal c_with 
      on transaction_info.date = c_with.date 
      and transaction_info.brand_name = c_with.brand_name 
      and transaction_info.market_name = c_with.market_name 
      and transaction_info.acquisition_channel = c_with.acquisition_channel