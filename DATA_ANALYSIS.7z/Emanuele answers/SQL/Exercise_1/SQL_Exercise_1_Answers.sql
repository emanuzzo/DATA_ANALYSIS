 
---- note: the fact table (tbl_api_calls has been imported by import csv 
---- while for the dim table I have created it via interface and then  I insert value in hard 
--- scripting. The only reason is just to keep the exercise quite practical. 
--- another important not is that I am not really a fan of hard scriptev variable
-- so, basing this exercise on SQL lite dialect, I have declared a Common Table Expression (CTE) 
--  have the advantage of keeping the date as parameter in only 1 site per query to make the code more 
-- mainteinable
--furthermore I have takne the freedom of choising a different date from that one given in the exercise (see note to answer 2) 
-- the code has been formatted on https://www.dpriver.com/pp/sqlformat.htm

DELETE
FROM dim_category;


INSERT INTO dim_category (category_id, Category_Name)
VALUES (1, 'Deposit'),
       (2, 'Bonus'),
       (3, 'Login');

--- answer number 1
WITH const AS
  (SELECT const.target_date
   FROM
     (SELECT Strftime("2024-12-31t23:59:59") --- only this parameter to declare
 AS target_date) const),
     details AS
  (SELECT category_name,
          brand,
          Count(*) AS call_count
   FROM tbl_api_calls fact
   LEFT JOIN dim_category dim_tab ON fact.category_id = dim_tab.category_id
   WHERE Strftime(date) <=
       (SELECT target_date
        FROM const) GROUP  BY category_name,
                              brand
     ORDER  BY dim_tab.category_id) -- the order by clause is not even necessary but

SELECT *
FROM details
UNION ALL
SELECT 'Totals' AS category_name,
       'All' AS brand,
       Count(*) AS call_count
FROM tbl_api_calls
WHERE Strftime(date) <=
    (SELECT target_date
     FROM const);


--- answer number 2   
--- note, in the exercise it was asked a target date the 15th of January,
--- but no acitivity has been done on that day so I impose the 19th
-- code formatted with https://sqlformat.org/
 WITH const AS
  (SELECT const.target_date
   FROM
     (SELECT STRFTIME("2024-01-19T23:59:59") --- only this parameter to declare
 AS target_date) const),
      details AS
  (SELECT category_name,
          brand,
          count(*) AS call_count
   FROM tbl_api_calls fact
   LEFT JOIN dim_category dim_tab ON fact.category_id = dim_tab.Category_id
   WHERE date(Date) <=
       (SELECT date(target_date)
        FROM const)
   GROUP BY category_name,
            brand
   ORDER BY dim_tab.Category_id)
SELECT category_name AS 'Call Category',
       brand AS 'Brand',
       call_count AS 'Call_Count'
FROM details
UNION ALL
SELECT 'MTD Total' AS 'Call Category',
       'All' AS 'Brand',
       count(*)
FROM tbl_api_calls
WHERE date(STRFTIME(Date)) <=
    (SELECT date(target_date)
     FROM const)
UNION ALL
SELECT 'DAILY TOTAL ('||
  (SELECT date(target_date)
   FROM const)||')' AS 'Call Category',
       'All' AS 'Brand',
       count(*)
FROM tbl_api_calls
WHERE date(STRFTIME(Date)) =
    (SELECT date(target_date)
     FROM const)
UNION ALL
SELECT 'PREVIOUS DAY ('||
  (SELECT date(target_date, '-1 day')
   FROM const)||')' AS 'Call Category',
       'All' AS 'Brand',
       count(*)
FROM tbl_api_calls
WHERE date(STRFTIME(Date)) =
    (SELECT date(target_date, '-1 day')
     FROM const)
UNION ALL
SELECT 'DAILY CHANGE' AS 'Call Category',
       'All' AS 'Brand',
       count(*) -
  (SELECT count(*)
   FROM tbl_api_calls
   WHERE date(STRFTIME(Date)) =
       (SELECT date(target_date, '-1 day')
        FROM const))
FROM tbl_api_calls
WHERE date(STRFTIME(Date)) =
    (SELECT date(target_date)
     FROM const) ;
 
 