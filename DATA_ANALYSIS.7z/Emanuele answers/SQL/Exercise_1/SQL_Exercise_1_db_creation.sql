CREATE TABLE "dim_category" (
	"Category_id"	INTEGER UNIQUE,
	"Category_Name"	TEXT UNIQUE,
	PRIMARY KEY("Category_id")
);

INSERT INTO dim_category (category_id, Category_Name)
VALUES (1, 'Deposit'),
       (2, 'Bonus'),
       (3, 'Login');

CREATE TABLE "tbl_api_calls" (
	"Date"	TEXT,
	"request_id"	INTEGER,
	"category_id"	INTEGER,
	"brand"	TEXT,
	PRIMARY KEY("request_id")
);

INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-11T08:01:51', '109', '2', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-18T08:01:55', '108', '2', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-08T08:06:50', '107', '2', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-18T08:01:55', '106', '2', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-07T08:03:59', '105', '2', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-19T08:01:49', '104', '2', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-11T08:01:52', '103', '2', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-10T08:01:50', '102', '2', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-08T08:06:50', '101', '2', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-02T08:08:19', '100', '2', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-19T08:01:49', '99', '2', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-08T08:06:50', '98', '2', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-11T08:01:51', '97', '2', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-02T08:08:18', '96', '2', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-18T08:01:55', '95', '2', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-10T08:01:50', '94', '2', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-07T08:03:58', '93', '2', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-07T08:03:58', '92', '2', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-10T08:01:50', '91', '2', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-19T08:01:49', '90', '2', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-08T08:06:50', '89', '2', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-11T08:01:51', '88', '2', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-02T08:08:17', '87', '2', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-18T08:01:55', '86', '2', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-07T08:03:59', '85', '2', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-19T08:01:50', '84', '2', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-08T08:06:51', '83', '2', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-02T08:08:22', '82', '2', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-10T08:01:51', '81', '2', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-18T08:01:57', '80', '2', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-11T08:01:52', '79', '2', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-11T08:01:52', '78', '2', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-07T08:04:00', '77', '2', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-02T08:08:23', '76', '2', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-18T08:01:57', '75', '2', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-10T08:01:51', '74', '2', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-08T08:06:51', '73', '2', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-19T08:01:50', '72', '2', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-07T15:55:45', '71', '1', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-08T02:08:37', '70', '1', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-19T04:21:05', '69', '1', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-14T06:55:11', '68', '1', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-31T00:33:06', '67', '1', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-24T06:34:29', '66', '1', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-19T05:53:39', '65', '1', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-25T11:52:55', '64', '1', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-12T21:25:53', '63', '1', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-26T12:30:58', '62', '1', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-01T03:46:19', '61', '1', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-01T06:20:58', '60', '1', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-28T02:34:36', '59', '1', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-12T03:46:19', '58', '1', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-05T02:14:46', '57', '1', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-29T19:09:39', '56', '1', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-19T21:56:22', '55', '1', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-09T00:11:53', '54', '1', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-08T08:08:41', '53', '1', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-25T03:38:03', '52', '1', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-29T06:21:51', '51', '1', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-12T01:05:04', '50', '1', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-01T02:59:30', '49', '1', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-26T02:10:26', '48', '1', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-13T18:41:05', '47', '3', 'Casino Green');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-13T18:41:05', '46', '3', 'Casino Green');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-20T18:09:34', '45', '3', 'Casino Green');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-13T18:41:05', '44', '3', 'Casino Green');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-05T04:00:28', '43', '3', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-19T00:50:32', '42', '3', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-02T02:02:19', '41', '3', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-07T18:07:23', '40', '3', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-31T22:57:11', '39', '3', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-29T20:04:08', '38', '3', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-06T11:40:25', '37', '3', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-07T18:06:55', '36', '3', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-10T09:42:35', '35', '3', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-10T09:42:26', '34', '3', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-10T09:42:29', '33', '3', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-10T09:35:39', '32', '3', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-10T09:35:18', '31', '3', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-30T11:53:10', '30', '3', 'Casino Orange');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-08T08:02:50', '29', '2', 'Casino Green');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-19T08:00:21', '28', '2', 'Casino Green');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-07T08:00:51', '27', '2', 'Casino Green');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-10T08:00:21', '26', '2', 'Casino Green');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-02T08:01:08', '25', '2', 'Casino Green');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-11T08:00:22', '24', '2', 'Casino Green');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-07T08:00:51', '23', '2', 'Casino Green');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-18T08:00:22', '22', '2', 'Casino Green');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-10T08:00:22', '21', '2', 'Casino Green');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-08T08:02:50', '20', '2', 'Casino Green');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-19T08:00:21', '19', '2', 'Casino Green');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-02T08:01:09', '18', '2', 'Casino Green');
-- the line that should be the 17 in the exercise was wrong (I guess) so I assume it has to be 17 and not 1 
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-07T13:38:56', '17', '1', 'Casino Green');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-28T15:26:13', '16', '1', 'Casino Green');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-28T14:47:16', '15', '1', 'Casino Green');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-28T15:23:09', '14', '1', 'Casino Green');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-28T14:25:33', '13', '1', 'Casino Green');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-28T17:04:50', '12', '1', 'Casino Green');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-29T12:35:58', '11', '1', 'Casino Green');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-28T14:27:35', '10', '1', 'Casino Green');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-28T18:23:00', '9', '1', 'Casino Green');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-28T14:21:52', '8', '1', 'Casino Green');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-28T14:11:06', '7', '1', 'Casino Green');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-28T15:39:44', '6', '1', 'Casino Green');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-28T14:44:05', '5', '1', 'Casino Green');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-30T02:50:26', '4', '1', 'Casino Green');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-31T03:36:01', '3', '1', 'Casino Green');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-20T18:21:59', '2', '1', 'Casino Green');
INSERT INTO "main"."tbl_api_calls" ("Date", "request_id", "category_id", "brand") VALUES ('2024-01-08T08:05:08', '1', '1', 'Casino Green');
 

